var express = require('express');
var router = express.Router();

var users = {
    test: {name: 'Hannah', email:'a1760973@student.adelaide.edu.au'},
    test2: {name: 'Test User 2', email:'test2@example.example'}
};

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
/*
router.use(function(req, res, next) {

  if(!('user' in req.session)){
    res.sendStatus(403);
    return;
  }

  next();

});*/

//add new workspaces
var tasks = [];
router.post('/addTask', function(req, res, next) {
    var title = req.body.title;
    var task = {title: title};
    tasks.push(task);
    res.end();
});

router.get('/getTasks', function(req, res, next) {
    res.send(tasks);
});

//post new notifications
var posts = [];
router.post('/addPost', function(req, res, next) {
    var ptitle = req.body.ptitle;
    var pcontent = req.body.pcontent;
    var postTime = req.body.postTime;
    var post = { ptitle: ptitle, postTime: postTime, pcontent: pcontent };
    posts.push(post);
    res.end();
});

router.get('/getPosts', function(req, res, next) {
    res.send(posts);
});


module.exports = router;
