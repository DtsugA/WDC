var express = require('express');
var router = express.Router();
var argon2 = require('argon2');

var users = {
    test: {password: '111', name: 'Hannah', email:'a1760973@student.adelaide.edu.au'}
};

router.use(function(req, res, next) {
  console.log(req.session);
  next();
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/dbtest', function(req, res, next) {
    req.pool.getConnection(function(err,connection) {
        if (err) {
          res.sendStatus(500);
          return;
        }
        var query = "SHOW TABLES";
        connection.query(query, function(err, rows, fields) {
            connection.release();
            if (err) {
                res.sendStatus(500);
                return;
            }
            res.json(rows);
        });
    });
});

router.post('/login', function(req, res, next) {
  // { user: 'email', pass: 'pass'}

  console.log(req.session);

  req.pool.getConnection( function(err,connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var query = "SELECT * FROM Manager WHERE Firstname = Hannah";
    connection.query(query, [req.body.user,req.body.pass], async function(err, rows, fields) {
      connection.release(); // release connection
      if (err) {
        res.sendStatus(500);
        return;
      }

      if(rows.length > 0){

        try {
          if (await argon2.verify(rows[0].password, req.body.pass)) {
            delete rows[0].password;
            req.session.user = rows[0];
            res.end();
            return;
          }
        } catch (err) {
          console.log(err);
        }

      }
      res.sendStatus(401);

    });
  });

  console.log(req.session);

});

router.post('/logout', function(req, res, next) {
  // { user: 'email', pass: 'pass'}

  console.log(req.session);
  delete req.session.user;
  res.sendStatus(200);
  console.log(req.session);

});

module.exports = router;
