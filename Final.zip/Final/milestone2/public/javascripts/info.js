//---------------onclick---------------//
////////////jump to other webpage -- manager//////////
document.getElementById("manager").addEventListener("click", function(){
  window.location.href="manager_info.html";
});

document.getElementById("search").addEventListener("click", function(){
  window.location.href="search.html";
});

document.getElementById("noti").addEventListener("click", function(){
  window.location.href="noti.html";
});

document.getElementById("home").addEventListener("click", function(){
  window.location.href="home.html";
});

//////////small screen//////////
document.getElementById("home1").addEventListener("click", function(){
  window.location.href="home.html";
});

document.getElementById("noti1").addEventListener("click", function(){
  window.location.href="noti.html";
});

document.getElementById("search1").addEventListener("click", function(){
  window.location.href="search.html";
});

document.getElementById("manager1").addEventListener("click", function(){
  window.location.href="manager_info.html";
});

//////////invite member//////////
var log = "block";
var clo = "none";

document.getElementById("memb3").addEventListener("click", function(){
  document.getElementById('member').style.display=log;
});
document.getElementById("memb4").addEventListener("click", function(){
  document.getElementById('member').style.display=log;
});

document.getElementById("close_memb3").addEventListener("click", function(){
  document.getElementById('member').style.display=clo;
});

//////////user information//////////
//Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}

//////////show or hide page//////////
var info = document.getElementById("info");
var psw = document.getElementById("psw");
var mem = document.getElementById("mem");

document.getElementById("showinfo").addEventListener("click", function(){
  if (info.style.display == "none") {
    info.style.display = "block";
    psw.style.display = "none";
    mem.style.display = "none";
  }
});

document.getElementById("showpsw").addEventListener("click", function(){
  if (psw.style.display == "none") {
    info.style.display = "none";
    psw.style.display = "block";
    mem.style.display = "none";
  }
});

document.getElementById("showmem").addEventListener("click", function(){
  if (psw.style.display == "none") {
    info.style.display = "none";
    psw.style.display = "none";
    mem.style.display = "block";
  }
});
//---------------end of onclick---------------//