//---------------onclick---------------//
////////////jump to other webpage -- manager//////////
document.getElementById("manager").addEventListener("click", function(){
  window.location.href="manager_info.html";
});

document.getElementById("search").addEventListener("click", function(){
  window.location.href="search.html";
});

document.getElementById("noti").addEventListener("click", function(){
  window.location.href="noti.html";
});

document.getElementById("home").addEventListener("click", function(){
  window.location.href="home.html";
});

//////////small screen//////////
document.getElementById("home1").addEventListener("click", function(){
  window.location.href="home.html";
});

document.getElementById("noti1").addEventListener("click", function(){
  window.location.href="noti.html";
});

document.getElementById("search1").addEventListener("click", function(){
  window.location.href="search.html";
});

document.getElementById("manager1").addEventListener("click", function(){
  window.location.href="manager_info.html";
});

//////////invite member//////////
var log = "block";
var clo = "none";

document.getElementById("memb").addEventListener("click", function(){
  document.getElementById('member').style.display=log;
});

document.getElementById("close_memb").addEventListener("click", function(){
  document.getElementById('member').style.display=clo;
});

//////////add new workspace//////////
document.getElementById("add").addEventListener("click", function(){
  document.getElementById('workspace').style.display=log;
});

document.getElementById("close_add").addEventListener("click", function(){
  document.getElementById('workspace').style.display=clo;
});
//---------------end of onclick---------------//

//////////sub task//////////
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
    x.previousElementSibling.className += " w3-lightgrey";
  } else {
    x.className = x.className.replace(" w3-show", "");
    x.previousElementSibling.className =
    x.previousElementSibling.className.replace(" w3-lightgrey", "");
  }
}

//////////choose status//////////
function Cstatus() {
  var y = document.getElementById("cStatus");
  if (y.className.indexOf("w3-show") == -1) {
    y.className += " w3-show";
    y.previousElementSibling.className += " w3-lightgrey";
  } else {
    y.className = y.className.replace(" w3-show", "");
    y.previousElementSibling.className =
    y.previousElementSibling.className.replace(" w3-lightgrey", "");
  }
}

//////////create new Workspace//////////
function addTask() {
  var title = document.getElementById("input").value;
  var addTaskRequest = new XMLHttpRequest();

  addTaskRequest.onreadystatechange = function() {
    if (addTaskRequest.readyState == 4) {
      if (addTaskRequest.status == 200) {
        console.log("Successful");
      }
      if (addTaskRequest.status == 404) {
        console.log('404 Not Found');
      }
    }
  };

  addTaskRequest.open('POST', "/users/addTask", true);
  addTaskRequest.setRequestHeader("Content-type", "application/json");
  addTaskRequest.send(JSON.stringify({ "title": title}));
}

//////////append tasks//////////
function appendTasks(task) {
  var Div = document.createElement("div");
  var Ti = document.createElement("p");

  Div.className = 'eachTask';
  Ti.className = 'TaskName';

  Div.appendChild(Ti);
  Ti.innerText = task.title;
  document.getElementById('posts').appendChild(Div);
}

//////////get tasks//////////
function getTasks() {
  var getTasksRequest = new XMLHttpRequest();
  var Class = document.getElementsByClassName('eachTask');
  var AllCreatedTasksID = document.getElementById('posts');

  getTasksRequest.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      while (Class.length > 0) {
        AllCreatedTasksID.removeChild(Class[0]);
      }

      var Tasks = JSON.parse(getTasksRequest.responseText);
      for (var i = 0; i < 100; i++) {
        appendTasks(Tasks[i]);
      }
    }
  };

  getTasksRequest.open("GET", "/users/getTasks", true);
  getTasksRequest.send();
}

window.οnlοad = getTasks();
