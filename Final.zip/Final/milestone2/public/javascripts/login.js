//---------------onclick---------------//
//////////LOG OUT//////////
document.getElementById("out").addEventListener("click", function(){
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
        console.log('User signed out.');
    });
});

//////////log in page//////////
var log = "block";
var clo = "none";

document.getElementById("log").addEventListener("click", function(){
  document.getElementById('login').style.display=log;
});

document.getElementById("close_log").addEventListener("click", function(){
  document.getElementById('login').style.display=clo;
});

//sign up page
document.getElementById("sign").addEventListener("click", function(){
  document.getElementById('signup').style.display=log;
});

document.getElementById("close_sign").addEventListener("click", function(){
  document.getElementById('signup').style.display=clo;
});

//////////Log in with Google//////////
function onSuccess(googleUser) {
     console.log('Logged in as: ' + googleUser.getBasicProfile().getName());
}

function onFailure(error) {
     console.log(error);
}

function renderButton() {
    gapi.signin2.render('my-signin2', {
        'scope': 'profile email',
        'width': 240,
        'height': 50,
        'longtitle': true,
        'theme': 'dark',
        'onsuccess': onSuccess,
        'onfailure': onFailure
    });
}

window.fbAsyncInit = function() {
    FB.init({
      appId            : 'your-app-id',
      autoLogAppEvents : true,
      xfbml            : true,
      version          : 'v7.0'
    });
};


//////////log in//////////
var mysql = require('mysql');
var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var path = require('path');

/*/////////////
//////SQL//////
/////////////*/


/*//////LOG IN//////*/
app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());

app.get('/', function(request, response) {
	response.sendFile(path.join(__dirname + '/index.html'));
});


app.post('/auth', function(request, response) {
	var email = request.body.email;
	var password = request.body.password;
	if (email && password) {
		connection.query(function(error, results, fields) {
			if (results.length > 0) {
				request.session.loggedin = true;
				request.session.email = email;
				response.redirect('/home');
			} else {
				response.send('Incorrect');
			}
			response.end();
		});
	} else {
		response.send('Enter Email or Password');
		response.end();
	}
});

app.get('/home', function(request, response) {
	if (request.session.loggedin) {
		response.send('WELCOME! ' + request.session.username);
	} else {
		response.send('Do you want to LOGIN?');
	}
	response.end();
});

app.listen(3000);
/*////////////////////*/