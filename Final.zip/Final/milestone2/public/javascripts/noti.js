//---------------onclick---------------//
////////////jump to other webpage -- manager//////////
document.getElementById("manager").addEventListener("click", function(){
  window.location.href="manager_info.html";
});

document.getElementById("search").addEventListener("click", function(){
  window.location.href="search.html";
});

document.getElementById("noti").addEventListener("click", function(){
  window.location.href="noti.html";
});

document.getElementById("home").addEventListener("click", function(){
  window.location.href="home.html";
});

//////////small screen//////////
document.getElementById("home1").addEventListener("click", function(){
  window.location.href="home.html";
});

document.getElementById("noti1").addEventListener("click", function(){
  window.location.href="noti.html";
});

document.getElementById("search1").addEventListener("click", function(){
  window.location.href="search.html";
});

document.getElementById("manager1").addEventListener("click", function(){
  window.location.href="manager_info.html";
});

//////////invite member//////////
var log = "block";
var clo = "none";

document.getElementById("mem1").addEventListener("click", function(){
  document.getElementById('member').style.display=log;
});

document.getElementById("close_mem1").addEventListener("click", function(){
  document.getElementById('member').style.display=clo;
});

//////////open the form//////////
document.getElementById("add_noti").addEventListener("click", function(){
  document.getElementById('notification').style.display="block";
});

//////////close the form//////////
document.getElementById("close_noti").addEventListener("click", function(){
  document.getElementById('notification').style.display="none";
});

//////////Back to Top//////////
window.onscroll = function() {scrollFunction()};

function scrollFunction() {console.log(121);
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("toTop").style.display = "block";
    }else {
        document.getElementById("toTop").style.display = "none";
    }
}

document.getElementById("go").addEventListener("click", function(){
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
});
//---------------end of onclick---------------//



//////////Notification//////////
//var num = 0;
function addPost() {
  var ptitle = document.getElementById("inputNoti").value;
  var pcontent = document.getElementById("postNoti").value;
  var addPostRequest = new XMLHttpRequest();

  addPostRequest.onreadystatechange = function() {
    if (addPostRequest.readyState == 4) {
      if (addPostRequest.status == 200) {
        console.log("Successful");
      }
      if (addPostRequest.status == 404) {
        console.log('404 Not Found');
      }
    }
  };

  addPostRequest.open('POST', "/users/addPost", true);
  addPostRequest.setRequestHeader("Content-type", "application/json");
  addPostRequest.send(JSON.stringify({ "ptitle": ptitle, "pcontent": pcontent }));
  //num++;
}

//////////append tasks//////////
function appendPosts(post) {
  var pDiv = document.createElement("div");
  var pTi = document.createElement("p");
  var pCon = document.createElement("p");

  pDiv.className = 'eachPost';
  pTi.className = 'PostName';
  pCon.className = 'PostInfo';

  pDiv.appendChild(pTi);
  pDiv.appendChild(pCon);
  pTi.innerText = post.ptitle;
  pCon.innerText = post.pcontent;
  document.getElementById('postsNoti').appendChild(pDiv);
}

//////////get tasks//////////
function getPosts() {
  var getPostsRequest = new XMLHttpRequest();
  var pClass = document.getElementsByClassName('eachPost');
  var AllPostsID = document.getElementById('postsNoti');
  getPostsRequest.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      while (pClass.length > 0) {
        AllPostsID.removeChild(pClass[0]);
      }

      var Posts = JSON.parse(getPostsRequest.responseText);
      for (var i = 0; i < 100; i++) {
        appendPosts(Posts[i]);
      }
    }
  };
  getPostsRequest.open("GET", "/users/getPosts", true);
  getPostsRequest.send();
}
/*
function removeElement(x)
{
  //child.parentNode.removeChild(child);
  var text = document.getElementById("pTi" + x);
  if (text !== null)
  {
    text.parentNode.removeChild(pTi);
  }
  var time = document.getElementById("pCon" + x);
  if (time !== null)
  {
    time.parentNode.removeChild(pCon);
  }
  number--;
}*/
