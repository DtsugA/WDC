-- //////////check the detail from tables//////////
-- Manager detail
SELECT * FROM Manager;
-- Users detail
SELECT * FROM Users;
-- Workspace detail
SELECT * FROM Workspace;
-- Task detail
SELECT * FROM Task;
-- SubTask detail
SELECT * FROM SubTask;
-- Groups detail
SELECT * FROM Groups;
-- Notification detail
SELECT * FROM Notification;

-- //////////select from a table with specific detail//////////
-- Manager with 1 detail
SELECT ManagerID FROM Manager;
SELECT LastName FROM Manager;
SELECT FirstName FROM Manager;
SELECT Email FROM Manager;
SELECT Phone FROM Manager;
SELECT GroupName FROM Manager;
-- Manager with 2 details
SELECT ManagerID, LastName FROM Manager;
SELECT ManagerID, FirstName FROM Manager;
SELECT ManagerID, Email FROM Manager;
SELECT ManagerID, Phone FROM Manager;
SELECT ManagerID, GroupName FROM Manager;
SELECT LastName, FirstName FROM Manager;
SELECT LastName, Email FROM Manager;
SELECT LastName, Phone FROM Manager;
SELECT LastName, GroupName FROM Manager;
SELECT FirstName, Email FROM Manager;
SELECT FirstName, Phone FROM Manager;
SELECT FirstName, GroupName FROM Manager;
SELECT Email, Phone FROM Manager;
SELECT Email, GroupName FROM Manager;
SELECT Phone, GroupName FROM Manager;
-- Manager with 3 details
SELECT ManagerID, LastName, FirstName FROM Manager;
SELECT ManagerID, LastName, Email FROM Manager;
SELECT ManagerID, LastName, Phone FROM Manager;
SELECT ManagerID, LastName, GroupName FROM Manager;
SELECT ManagerID, FirstName, Email FROM Manager;
SELECT ManagerID, FirstName, Phone FROM Manager;
SELECT ManagerID, FirstName, GroupName FROM Manager;
SELECT ManagerID, Email, Phone FROM Manager;
SELECT ManagerID, Email, GroupName FROM Manager;
SELECT ManagerID, Phone, GroupName FROM Manager;
SELECT LastName, FirstName, Email FROM Manager;
SELECT LastName, FirstName, Phone FROM Manager;
SELECT LastName, FirstName, GroupName FROM Manager;
SELECT LastName, Email, Phone FROM Manager;
SELECT LastName, Email, GroupName FROM Manager;
SELECT LastName, Phone, GroupName FROM Manager;
SELECT FirstName, Email, Phone FROM Manager;
SELECT FirstName, Phone, GroupName FROM Manager;
-- Manager with 4 details
SELECT ManagerID, LastName, FirstName, Email FROM Manager;
SELECT ManagerID, LastName, FirstName, Phone FROM Manager;
SELECT ManagerID, LastName, FirstName, GroupName FROM Manager;
SELECT ManagerID, LastName, Email, Phone FROM Manager;
SELECT ManagerID, LastName, Email, GroupName FROM Manager;
SELECT ManagerID, FirstName, Email, Phone FROM Manager;
SELECT ManagerID, FirstName, Phone, GroupName FROM Manager;
SELECT ManagerID, Email, Phone, GroupName FROM Manager;
SELECT LastName, FirstName, Email, GroupName FROM Manager;
SELECT LastName, FirstName, Phone, GroupName FROM Manager;
SELECT LastName, Email, Phone, GroupName FROM Manager;
-- Manager with 5 details
SELECT ManagerID, LastName, FirstName, Email, Phone FROM Manager;
SELECT ManagerID, LastName, FirstName, Phone, GroupName FROM Manager;
SELECT ManagerID, LastName, Email, Phone, GroupName FROM Manager;
SELECT ManagerID, FirstName, Email, Phone, GroupName FROM Manager;
-- Manager with 6 details
SELECT ManagerID, LastName, FirstName, Email, Phone, GroupName FROM Manager;

-- Users with 1 detail
SELECT UserID FROM Users;
SELECT LastName FROM Users;
SELECT FirstName FROM Users;
SELECT Email FROM Users;
SELECT Phone FROM Users;
-- Users with 2 details
SELECT UserID, LastName FROM Users;
SELECT UserID, FirstName FROM Users;
SELECT UserID, Email FROM Users;
SELECT UserID, Phone FROM Users;
SELECT LastName, FirstName FROM Users;
SELECT LastName, Email FROM Users;
SELECT LastName, Phone FROM Users;
SELECT FirstName, Email FROM Users;
SELECT FirstName, Phone FROM Users;
SELECT Email, Phone FROM Users;
-- Users with 3 details
SELECT UserID, LastName, FirstName FROM Users;
SELECT UserID, LastName, Email FROM Users;
SELECT UserID, LastName, Phone FROM Users;
SELECT UserID, FirstName, Email FROM Users;
SELECT UserID, FirstName, Phone FROM Users;
SELECT UserID, Email, Phone FROM Users;
SELECT LastName, FirstName, Email FROM Users;
SELECT LastName, FirstName, Phone FROM Users;
SELECT LastName, Email, Phone FROM Users;
SELECT FirstName, Email, Phone FROM Users;
-- Users with 4 details
SELECT UserID, LastName, FirstName, Email FROM Users;
SELECT UserID, LastName, FirstName, Phone FROM Users;
SELECT UserID, LastName, Email, Phone FROM Users;
SELECT UserID, FirstName, Email, Phone FROM Users;
SELECT UserID, LastName, Email, GroupName FROM Users;
SELECT UserID, FirstName, Email, Phone FROM Users;
SELECT UserID, FirstName, Phone, GroupName FROM Users;
SELECT UserID, Email, Phone, GroupName FROM Users;
SELECT LastName, FirstName, Email, GroupName FROM Users;
SELECT LastName, FirstName, Phone, GroupName FROM Users;
SELECT LastName, Email, Phone, GroupName FROM Users;
-- Manager with 5 details
SELECT UserID, LastName, FirstName, Email, Phone FROM Users;
SELECT UserID, LastName, FirstName, Phone, GroupName FROM Users;
SELECT UserID, LastName, Email, Phone, GroupName FROM Users;
SELECT UserID, FirstName, Email, Phone, GroupName FROM Users;
-- Manager with 6 details
SELECT UserID, LastName, FirstName, Email, Phone, GroupName FROM Users;

-- Workspace with 1 detail
SELECT WorkspaceName FROM Workspace;
SELECT TaskName FROM Workspace;
-- Workspace with 2 details
SELECT WorkspaceName, TaskName FROM Workspace;

-- Task with 1 detail
SELECT SubTaskName FROM Task;
SELECT TaskName FROM Task;
-- Task with 2 details
SELECT SubTaskName, TaskName FROM Task;

-- SubTask with 1 detail
SELECT SubTaskName FROM SubTask;
SELECT FirstName FROM SubTask;
SELECT Status FROM SubTask;
-- SubTask with 2 details
SELECT SubTaskName, FirstName FROM SubTask;
SELECT SubTaskName, Status FROM SubTask;
SELECT FirstName, Status FROM SubTask;
-- SubTask with 3 detail
SELECT SubTaskName, FirstName, Status FROM SubTask;

-- Groups with 1 detail
SELECT GroupName FROM Groups;
SELECT UserID FROM Groups;
SELECT ManagerID FROM Groups;
-- Groups with 2 details
SELECT GroupName, UserID FROM Groups;
SELECT GroupName, ManagerID FROM Groups;
SELECT UsersID, ManagerID FROM Groups;
-- Groups with 3 details
SELECT GroupName, UserID, ManagerID FROM Groups;

-- Notification with 1 detail
SELECT NotiName FROM Notification;
SELECT NotiContent FROM Notification;
SELECT ManagerID FROM Notification;
-- Notification with 2 details
SELECT NotiName, NotiContent FROM Notification;
SELECT NotiName, ManagerID FROM Notification;
SELECT NotiContent, ManagerID FROM Notification;
-- Notification with 3 details
SELECT NotiName, NotiContent, ManagerID FROM Notification;

-- //////////the distinct values//////////
-- all distinct value
SELECT DISTINCT ManagerID FROM Manager;
-- it can be used in count the number of members in a group
SELECT COUNT (DISTINCT UserID) FROM Groups;
SELECT COUNT(UserID) FROM Groups;
SELECT COUNT(UserID) FROM Users;

-- //////////select the user or manager in the same group//////////
-- users in same group
SELECT * FROM Users
WHERE GroupName='BTS';

SELECT * FROM Users
WHERE GroupName='UoA';

-- //////////sorted by group(check who in the same group)//////////
-- users
SELECT * FROM Users
ORDER BY GroupName;
-- manager
SELECT * FROM Manager
ORDER BY GroupName;

-- //////////check users or managers whoes phone number is NULL//////////
-- is NULL
SELECT FirstName, Email, Phone, UsersID
FROM Users
WHERE Phone IS NULL;

SELECT FirstName, Email, Phone, ManagerID
FROM Manager
WHERE Phone IS NULL;

-- is not NULL
SELECT FirstName, Email, Phone, UsersID
FROM Users
WHERE Phone IS NOT NULL;

SELECT FirstName, Email, Phone, ManagerID
FROM Manager
WHERE Phone IS NOT NULL;

-- //////////select the users or managers with limit condition/////////
-- top 2 (just change the number)
SELECT TOP 2 * FROM Users;
SELECT TOP 2 * FROM Manager;

-- with limit condition groups
--(there is only group name can be the same)
SELECT TOP 2 * FROM Users
WHERE GroupName='BTS';
SELECT TOP 2 * FROM Manager
WHERE GroupName='UoA';

-- //////////to figure out the number of users by user ID//////////
SELECT COUNT(UserID)
FROM Users;

-- //////////find the user last name with a//////////
-- start
SELECT * FROM Users
WHERE LastName LIKE 'a%';

-- end
SELECT * FROM Users
WHERE LastName LIKE '%a';

-- with a in anywhere
SELECT * FROM Users
WHERE LastName LIKE '%a%';

-- second with a
SELECT * FROM Users
WHERE LastName LIKE '_a%';

-- start with a and at least have 3 character
SELECT * FROM Users
WHERE LastName LIKE 'a_%';

-- start with k and end with m
SELECT * FROM Users
WHERE LastName LIKE 'k%m';

-- not start with a
SELECT * FROM Users
WHERE LastName NOT LIKE 'a%';

-- all the user last name star with a or k
SELECT * FROM Users
WHERE LastName LIKE '[ak]%';

-- all the user last name star with a to k
SELECT * FROM Users
WHERE LastName LIKE '[a-k]%';

-- all the user last name not star with a or k
SELECT * FROM Users
WHERE LastName LIKE '[!ak]%';

SELECT * FROM Users
WHERE LastName NOT LIKE '[ak]%';

-- //////////choose the user in or not in the BTS group//////////
-- in
SELECT * FROM Users
WHERE GroupName IN ('BTS');

-- not in
SELECT * FROM Users
WHERE GroupName NOT IN ('BTS');

-- //////////between//////////
-- find the user ID between u111111 to u111119 or not
-- (if want to search between name or other, just change the contain in ' ')
SELECT * FROM Users
WHERE UserID BETWEEN 'u111111' AND 'u111119';

SELECT * FROM Users
WHERE UserID NOT BETWEEN 'u111111' AND 'u111119';

-- not contain the BTS group
SELECT * FROM Users
WHERE UserID BETWEEN 'u111111' AND 'u111119'
AND GroupName NOT IN ('BTS');

-- //////////aliases//////////
-- set two new aliases
SELECT UserID AS ID, Email AS [Email Address]
FROM Users;

-- select the user ID and email in same group with user ID
SELECT u.UserID, u.Email, g.GroupName
FROM Users AS u, Groups AS g
WHERE g.GroupName='BTS' AND u.UserID=g.UserID;

-- //////////join//////////
/*/////inner join with 2 tables/////*/
-- user ID in Users and Groups
SELECT Users.UserID, Groups.GroupName, Users.Email
FROM Users
INNER JOIN Groups
ON Users.UserID=Groups.UserID;

-- Manager ID in Manager and Groups
SELECT Manager.ManagerID, Groups.GroupName, Manager.Email
FROM Manager
INNER JOIN Groups
ON Manager.ManagerID=Groups.ManagerID;

-- Task name in Workspace and Task
SELECT Workspace.TaskName, Task.SubTaskName, Workspace.WorkspaceName
FROM Workspace
INNER JOIN Task
ON Workspace.TaskName=Task.TaskName;

-- SubTaskName in Task and SubTask
SELECT SubTask.SubTaskName, Task.TaskName, SubTask.Status
FROM SubTask
INNER JOIN Task
ON SubTask.SubTaskName=Task.SubTaskName;

-- First name in Users and SubTask
SELECT Users.FirstName, SubTask.TaskName, Users.Email
FROM Users
INNER JOIN SubTask
ON SubTask.FirstName=Users.FirstName;

/*/////inner join with 3 tables/////*/
-- in Users, Groups and Manager
SELECT Groups.UserID, Users.FirstName, Manager.FirstName
FROM ((Groups
INNER JOIN Users ON Groups.CustomerID = Users.UserID)
INNER JOIN Manager ON Groups.ManagerID = Manager.ManagerID);

/*/////left join/////*/
SELECT Groups.GroupName, Manager.FirstName
FROM Groups
LEFT JOIN Manager
ON Groups.ManagerID=Manager.ManagerID
ORDER BY Groups.GroupName;

/*/////right join/////*/
SELECT Groups.GroupName, Users.LastName, Users.FirstName
FROM Groups
RIGHT JOIN Users
ON Groups.UserID = Users.UserID
ORDER BY Groups.GroupName;

/*/////full outer join/////*/
SELECT Groups.GroupName, Users.FirstName
FROM Groups
FULL OUTER JOIN Users ON Groups.UserID = Users.UserID
ORDER BY Groups.GroupName;

/*/////self join/////*/
-- find users in the same group
SELECT A.FirstName AS FirstName1, B.FirstName AS FirstName2, A.GroupName
FROM Users A, Users B
WHERE A.UserID <> B.UserID
AND A.GroupName = B.GroupName
ORDER BY A.GroupName;

-- //////////union//////////
/*/////return different value from users and manager/////*/
SELECT GroupName FROM Users
UNION
SELECT GroupName FROM Manager
ORDER BY GroupName;

/*/////return all value/////*/
SELECT GroupName FROM Users
UNION ALL
SELECT GroupName FROM Manager
ORDER BY GroupName;

-- //////////group by group name//////////
-- count with user ID
SELECT COUNT(UserID), GroupName
FROM Users
GROUP BY GroupName;

-- sorted from high to low
SELECT COUNT(UserID), GroupName
FROM Users
GROUP BY GroupName;
ORDER BY COUNT(UserID) DESC;

-- //////////having//////////
-- Workspace having only 1 Task
SELECT COUNT(TaskName), TaskName
FROM Workspace
GROUP BY TaskName
HAVING COUNT(TaskName) = 1;

-- //////////exists//////////
-- check the Task name that are working
SELECT TaskName
FROM Task
WHERE EXISTS (SELECT FirstName FROM SubTask WHERE SubTask.SubTaskName = Task.SubTaskName AND Status = 'Working');

-- //////////any//////////
-- find from Task any Sub task name = Assignment3 and list the workspace name
SELECT WorkspaceName
FROM Workspace
WHERE TaskName = ANY (SELECT TaskName FROM Task WHERE SubTaskName = 'Assignment3');